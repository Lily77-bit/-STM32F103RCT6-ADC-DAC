#ifndef __UART_H
#define __UART_H


#include <stdio.h>
#include "stm32f10x.h"

void UART1_Init(uint32_t BaudRate);
void UART1_SendByte(uint8_t Data);
void UART1_SendString(char* Str);
void USART1_IRQHandler(void);



#endif


