#ifndef __UI_H
#define __UI_H

#include "stm32f10x.h"
#include "DAC_DMA.h"



// UI״̬ö��
typedef enum {
    UI_STATE_IDLE = 0,
    UI_STATE_MENU1,
    UI_STATE_MENU2,
    UI_STATE_MENU2_SCROLL  
} UI_State;

// ѡ��λ��ö��
typedef enum {
    SELECT_WAVE1_TYPE = 0,
    SELECT_WAVE2_TYPE,
    SELECT_WAVE1_FREQ,
    SELECT_WAVE2_FREQ,
    SELECT_WAVE1_AMP,
    SELECT_WAVE2_AMP,
    SELECT_WAVE1_PHASE,
    SELECT_WAVE2_PHASE,
    SELECT_MAX
} SelectPos;

// �����˵�����ѡ��ö�٣�������
typedef enum {
    WAVE_SELECT_NONE = 0,   // δѡ��
    WAVE_SELECT_CH1,         // ѡ��CH1
    WAVE_SELECT_CH2,         // ѡ��CH2
    WAVE_SELECT_CH3          // ѡ��CH3(�˻�)
} WaveSelect;

// ʱ����λ����
typedef struct {
    uint8_t index;
    uint16_t value_us;
    const char* str;
} TimeBaseLevel;

// ˫·ʾ���������ṹ��
typedef struct {
    uint8_t timebase_index;
    uint8_t is_running;
    float ch1_freq;
    float ch1_vpp;
    float ch2_freq;
    float ch2_vpp;
    uint8_t show_multiply;
    WaveSelect wave_select;      // ��ǰѡ��Ĳ��Σ�������
    uint8_t phase_editing;       // �Ƿ����ڱ༭��λ��������
    float phase_diff_deg;
    float phase_diff_rad;
    uint8_t phase_valid;
} DualScopeParam;

// UI�����ṹ��
typedef struct {
    UI_State state;
    SelectPos current_select;
    uint8_t is_editing;
    WaveConfig wave1_config;
    WaveConfig wave2_config;
    DualScopeParam scope_param;
} UI_Param;

// ȫ�ֱ���
extern UI_Param ui_param;
extern const TimeBaseLevel timebase_levels[10];


// ��������

const char* UI_GetWaveTypeName_CN(WaveType type);
void UI_SmoothWaveform(void);
void UI_Init(void);
void UI_EnterMenu1(void);
void UI_ExitMenu1(void);
void UI_EnterMenu2(void);
void UI_Handle(void);
void UI_Draw(void);
void UI_DrawMenu1(void);
void UI_DrawMenu1_Scroll(void);
void UI_DrawMenu2(void);
void UI_DrawMenu2_Multiply(void);

const char* UI_GetWaveTypeName(WaveType type);
void UI_SelectNext(void);
void UI_SelectPrev(void);
void UI_IncreaseValue(void);
void UI_DecreaseValue(void);
void UI_ConfirmEdit(void);

void UI_Scope_IncreaseTimeBase(void);
void UI_Scope_DecreaseTimeBase(void);
void UI_Scope_ToggleRunStop(void);
void UI_Scope_UpdateMeasure(void);
void UI_Scope_UpdatePhase(void);
uint16_t UI_Scope_GetSampleStep(void);

void UI_FormatFreq(char *str, float freq);
void UI_FormatVoltage(char *str, float voltage);
void UI_FormatPhase(char *str, float phase_deg);

// ����ѡ�����λ������������
void UI_SelectWave(WaveSelect wave);
void UI_AdjustPhaseIncrease(void);
void UI_AdjustPhaseDecrease(void);
void UI_TogglePhaseEdit(void);

// �������
void UI_ToggleMenu1Scroll(void);
void UI_ToggleMenu2Scroll(void);

#endif


