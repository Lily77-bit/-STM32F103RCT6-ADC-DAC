#include "DAC_DMA.h"
#include "Timer.h"
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/******************** ȫ�ֱ������� ********************/
uint16_t wave1_buffer[WAVE_BUFFER_SIZE] = {0};
uint16_t wave2_buffer[WAVE_BUFFER_SIZE] = {0};

/******************************************************************************
 * ��������: DAC_DMA_Init
 * ��������: ��ʼ��˫ͨ��DAC��DMA
 * ˵    ��: DAC1ʹ��TIM2������DAC2ʹ��TIM4������ʵ�ֶ���Ƶ��
 *****************************************************************************/
void DAC_DMA_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    DAC_InitTypeDef DAC_InitStructure;
    DMA_InitTypeDef DMA_InitStructure;
    
    // 1. ʹ��ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);
    
    // 2. GPIO���� - PA4(DAC1), PA5(DAC2)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // 3. DAC1���� - ʹ��TIM2����
    DAC_InitStructure.DAC_Trigger = DAC_Trigger_T2_TRGO;
    DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
    DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Enable;
    DAC_Init(DAC_Channel_1, &DAC_InitStructure);
    
    // 4. DAC2���� - ʹ��TIM4����
    DAC_InitStructure.DAC_Trigger = DAC_Trigger_T4_TRGO;
    DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
    DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Enable;
    DAC_Init(DAC_Channel_2, &DAC_InitStructure);
    
    // 5. ʹ��DAC
    DAC_Cmd(DAC_Channel_1, ENABLE);
    DAC_Cmd(DAC_Channel_2, ENABLE);
    
    // 6. DMA���� - ͨ��1 (DMA2_Channel3 -> DAC1)
    DMA_DeInit(DMA2_Channel3);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&DAC->DHR12R1;
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)wave1_buffer;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = WAVE_BUFFER_SIZE;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA2_Channel3, &DMA_InitStructure);
    
    DMA_Cmd(DMA2_Channel3, ENABLE);
    DAC_DMACmd(DAC_Channel_1, ENABLE);
    
    // 7. DMA���� - ͨ��2 (DMA2_Channel4 -> DAC2)
    DMA_DeInit(DMA2_Channel4);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&DAC->DHR12R2;
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)wave2_buffer;
    DMA_Init(DMA2_Channel4, &DMA_InitStructure);
    
    DMA_Cmd(DMA2_Channel4, ENABLE);
    DAC_DMACmd(DAC_Channel_2, ENABLE);
}

/******************************************************************************
 * ��������: DAC_GenerateSineWave
 * ��������: �������Ҳ�
 *****************************************************************************/
void DAC_GenerateSineWave(uint16_t *buffer, float amplitude, int16_t phase)
{
    uint16_t i;
    float phase_rad = (float)phase * M_PI / 180.0f;
    
    for (i = 0; i < WAVE_BUFFER_SIZE; i++)
    {
        float angle = 2.0f * M_PI * i / WAVE_BUFFER_SIZE + phase_rad;
        float value = (sinf(angle) + 1.0f) / 2.0f * amplitude / 3.3f * 4095.0f;
        
        if (value > 4095.0f) value = 4095.0f;
        if (value < 0.0f) value = 0.0f;
        
        buffer[i] = (uint16_t)value;
    }
}

/******************************************************************************
 * ��������: DAC_GenerateTriangleWave
 * ��������: �������ǲ�
 *****************************************************************************/
void DAC_GenerateTriangleWave(uint16_t *buffer, float amplitude, int16_t phase)
{
    uint16_t i;
    int16_t phase_offset;
    
    // ��������λ
    if (phase < 0)
        phase_offset = (int16_t)((float)(phase + 360) / 360.0f * WAVE_BUFFER_SIZE);
    else
        phase_offset = (int16_t)((float)phase / 360.0f * WAVE_BUFFER_SIZE);
    
    for (i = 0; i < WAVE_BUFFER_SIZE; i++)
    {
        int16_t idx = (i + phase_offset) % WAVE_BUFFER_SIZE;
        if (idx < 0) idx += WAVE_BUFFER_SIZE;
        
        float value;
        
        if (idx < WAVE_BUFFER_SIZE / 2)
            value = (float)idx / (WAVE_BUFFER_SIZE / 2) * amplitude / 3.3f * 4095.0f;
        else
            value = (2.0f - (float)idx / (WAVE_BUFFER_SIZE / 2)) * amplitude / 3.3f * 4095.0f;
        
        if (value > 4095.0f) value = 4095.0f;
        if (value < 0.0f) value = 0.0f;
        
        buffer[i] = (uint16_t)value;
    }
}

/******************************************************************************
 * ��������: DAC_GenerateSawtoothWave
 * ��������: ���ɾ�ݲ�
 *****************************************************************************/
void DAC_GenerateSawtoothWave(uint16_t *buffer, float amplitude, int16_t phase)
{
    uint16_t i;
    int16_t phase_offset;
    
    if (phase < 0)
        phase_offset = (int16_t)((float)(phase + 360) / 360.0f * WAVE_BUFFER_SIZE);
    else
        phase_offset = (int16_t)((float)phase / 360.0f * WAVE_BUFFER_SIZE);
    
    for (i = 0; i < WAVE_BUFFER_SIZE; i++)
    {
        int16_t idx = (i + phase_offset) % WAVE_BUFFER_SIZE;
        if (idx < 0) idx += WAVE_BUFFER_SIZE;
        
        float value = (float)idx / WAVE_BUFFER_SIZE * amplitude / 3.3f * 4095.0f;
        
        if (value > 4095.0f) value = 4095.0f;
        if (value < 0.0f) value = 0.0f;
        
        buffer[i] = (uint16_t)value;
    }
}

/******************************************************************************
 * ��������: DAC_GenerateSquareWave
 * ��������: ���ɷ���
 *****************************************************************************/
void DAC_GenerateSquareWave(uint16_t *buffer, float amplitude, int16_t phase)
{
    uint16_t i;
    int16_t phase_offset;
    uint16_t high_val = (uint16_t)(amplitude / 3.3f * 4095.0f);
    uint16_t low_val = 0;
    uint16_t mid_val = high_val / 2;
    
    if (phase < 0)
        phase_offset = (int16_t)((float)(phase + 360) / 360.0f * WAVE_BUFFER_SIZE);
    else
        phase_offset = (int16_t)((float)phase / 360.0f * WAVE_BUFFER_SIZE);
    
    for (i = 0; i < WAVE_BUFFER_SIZE; i++)
    {
        int16_t idx = (i + phase_offset) % WAVE_BUFFER_SIZE;
        if (idx < 0) idx += WAVE_BUFFER_SIZE;
        
        if (idx == 0 || idx == WAVE_BUFFER_SIZE / 2)
            buffer[i] = mid_val;
        else if (idx < WAVE_BUFFER_SIZE / 2)
            buffer[i] = high_val;
        else
            buffer[i] = low_val;
    }
}

/******************************************************************************
 * ��������: DAC_OutputWave1
 * ��������: �������1��DAC1��PA4��TIM2������
 *****************************************************************************/
void DAC_OutputWave1(WaveConfig *wave1)
{
    // ���ɲ�������
    switch (wave1->type)
    {
        case WAVE_SINE:
            DAC_GenerateSineWave(wave1_buffer, wave1->amplitude, wave1->phase);
            break;
        case WAVE_TRIANGLE:
            DAC_GenerateTriangleWave(wave1_buffer, wave1->amplitude, wave1->phase);
            break;
        case WAVE_SAWTOOTH:
            DAC_GenerateSawtoothWave(wave1_buffer, wave1->amplitude, wave1->phase);
            break;
        case WAVE_SQUARE:
            DAC_GenerateSquareWave(wave1_buffer, wave1->amplitude, wave1->phase);
            break;
        default:
            break;
    }
    
    // ����TIM2Ƶ�ʣ�DAC1��
    TIM2_DAC1_SetFrequency(wave1->freq);
}

/******************************************************************************
 * ��������: DAC_OutputWave2
 * ��������: �������2��DAC2��PA5��TIM4������
 *****************************************************************************/
void DAC_OutputWave2(WaveConfig *wave2)
{
    // ���ɲ�������
    switch (wave2->type)
    {
        case WAVE_SINE:
            DAC_GenerateSineWave(wave2_buffer, wave2->amplitude, wave2->phase);
            break;
        case WAVE_TRIANGLE:
            DAC_GenerateTriangleWave(wave2_buffer, wave2->amplitude, wave2->phase);
            break;
        case WAVE_SAWTOOTH:
            DAC_GenerateSawtoothWave(wave2_buffer, wave2->amplitude, wave2->phase);
            break;
        case WAVE_SQUARE:
            DAC_GenerateSquareWave(wave2_buffer, wave2->amplitude, wave2->phase);
            break;
        default:
            break;
    }
    
    // ����TIM4Ƶ�ʣ�DAC2��
    TIM4_DAC2_SetFrequency(wave2->freq);
}

/******************************************************************************
 * ��������: DAC_OutputWaves
 * ��������: ���˫·���Σ�����Ƶ�ʣ�
 *****************************************************************************/
void DAC_OutputWaves(WaveConfig *wave1, WaveConfig *wave2)
{
    DAC_OutputWave1(wave1);
    DAC_OutputWave2(wave2);
}

/******************************************************************************
 * ��������: DAC_UpdateFrequency
 * ��������: ����DAC1���Ƶ�ʣ����ݾɽӿڣ�
 *****************************************************************************/
void DAC_UpdateFrequency(uint32_t freq)
{
    TIM2_DAC1_SetFrequency(freq);
}

/******************************************************************************
 * ��������: DAC_UpdateFrequency_CH1
 * ��������: ����DAC1���Ƶ��
 *****************************************************************************/
void DAC_UpdateFrequency_CH1(uint32_t freq)
{
    TIM2_DAC1_SetFrequency(freq);
}

/******************************************************************************
 * ��������: DAC_UpdateFrequency_CH2
 * ��������: ����DAC2���Ƶ��
 *****************************************************************************/
void DAC_UpdateFrequency_CH2(uint32_t freq)
{
    TIM4_DAC2_SetFrequency(freq);
}

/******************************************************************************
 * ��������: DAC_StopOutput
 *****************************************************************************/
void DAC_StopOutput(void)
{
    DMA_Cmd(DMA2_Channel3, DISABLE);
    DMA_Cmd(DMA2_Channel4, DISABLE);
}



