#include "UI.h"
#include "OLED.h"
#include "Timer.h"
#include "ADC_DMA.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h> //��������abs() warnning



/******************** ʱ����λ�� ********************/
const TimeBaseLevel timebase_levels[10] = {
    {0,   50, "50u"},
    {1,  100, "0.1m"},
    {2,  200, "0.2m"},
    {3,  500, "0.5m"},
    {4, 1000, "1m"},
    {5, 2000, "2m"},
    {6, 5000, "5m"},
    {7, 10000, "10m"},
    {8, 20000, "20m"},
    {9, 50000, "50m"}
};

/******************** ȫ��UI���� ********************/
UI_Param ui_param = 
{
    .state = UI_STATE_IDLE,
    .current_select = SELECT_WAVE1_TYPE,
    .is_editing = 0,
    .wave1_config = {WAVE_SINE, 1000, 3.3f, 0},
    .wave2_config = {WAVE_SINE, 1000, 3.3f, 0},
    .scope_param = {4, 1, 0, 0, 0, 0, 0, WAVE_SELECT_NONE, 0, 0, 0, 0}
};

static uint16_t frozen_ch1[ADC_BUFFER_SIZE] = {0};
static uint16_t frozen_ch2[ADC_BUFFER_SIZE] = {0};

/******************** ����ѡ������ ********************/
const uint32_t freq_options[] = {10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000};
const uint8_t freq_options_count = sizeof(freq_options) / sizeof(freq_options[0]);

const float amp_options[] = {0.3f, 0.6f, 0.9f, 1.2f, 1.5f, 1.8f, 2.1f, 2.4f, 2.7f, 3.0f, 3.3f};
const uint8_t amp_options_count = sizeof(amp_options) / sizeof(amp_options[0]);




static uint16_t avg_ch1[128] = {0};
static uint16_t avg_ch2[128] = {0};
static uint8_t avg_initialized = 0;

// �ڻ��Ʋ���ʱʹ��ƽ��ֵ
void UI_SmoothWaveform(void)
{
    uint16_t i, step;
    step = UI_Scope_GetSampleStep();
    
    for (i = 0; i < 128; i++)
    {
        uint16_t sample_index = (uint32_t)i * step;
        if (sample_index >= ADC_BUFFER_SIZE)
            sample_index = ADC_BUFFER_SIZE - 1;
        
        uint16_t new_ch1 = ADC_Value[0][sample_index];
        uint16_t new_ch2 = ADC_Value[1][sample_index];
        
        if (!avg_initialized)
        {
            avg_ch1[i] = new_ch1;
            avg_ch2[i] = new_ch2;
        }
        else
        {
            // �򵥵�ͨ�˲�����ֵռ25%����ֵռ75%
            avg_ch1[i] = (avg_ch1[i] * 3 + new_ch1) / 4;
            avg_ch2[i] = (avg_ch2[i] * 3 + new_ch2) / 4;
        }
    }
    avg_initialized = 1;
}
/******************** �������ܺ��� ********************/

void UI_Init(void)
{
    ui_param.state = UI_STATE_IDLE;
    ui_param.current_select = SELECT_WAVE1_TYPE;
    ui_param.is_editing = 0;
    
    ui_param.wave1_config.type = WAVE_TRIANGLE;
    ui_param.wave1_config.freq = 1000;
    ui_param.wave1_config.amplitude = 3.3f;
    ui_param.wave1_config.phase = 0;
    
    ui_param.wave2_config.type = WAVE_SINE;
    ui_param.wave2_config.freq = 1000;
    ui_param.wave2_config.amplitude = 3.3f;
    ui_param.wave2_config.phase = 0;
    
    ui_param.scope_param.timebase_index = 4;
    ui_param.scope_param.is_running = 1;
    ui_param.scope_param.show_multiply = 0;
    ui_param.scope_param.wave_select = WAVE_SELECT_NONE;
    ui_param.scope_param.phase_editing = 0;
    ui_param.scope_param.ch1_freq = 0;
    ui_param.scope_param.ch1_vpp = 0;
    ui_param.scope_param.ch2_freq = 0;
    ui_param.scope_param.ch2_vpp = 0;
}

// �޸� UI_GetWaveTypeName �������������İ汾
const char* UI_GetWaveTypeName_CN(WaveType type)
{
    switch(type)
    {
        case WAVE_SINE:     return "����";
        case WAVE_TRIANGLE: return "����";
        case WAVE_SAWTOOTH: return "���";
        case WAVE_SQUARE:   return "����";
        default:            return "��";
    }
}

// ����Ӣ�İ汾���ڿռ����޵ĵط�
const char* UI_GetWaveTypeName(WaveType type)
{
    switch(type)
    {
        case WAVE_SINE:     return "Sine";
        case WAVE_TRIANGLE: return "Trian";
        case WAVE_SAWTOOTH: return "Sawth";
        case WAVE_SQUARE:   return "Squar";
        default:            return "None";
    }
}


void UI_FormatFreq(char *str, float freq)
{
    if (freq < 1000)
    {
        sprintf(str, "%d", (int)freq);
    }
    else if (freq < 10000)
    {
        int k = (int)(freq / 1000);
        int decimal = (int)((freq - k * 1000) / 100);
        sprintf(str, "%dK%d", k, decimal);
    }
    else if (freq < 100000)
    {
        int k = (int)(freq / 1000);
        int decimal = (int)((freq - k * 1000) / 100);
        if (decimal == 0)
        {
            sprintf(str, "%dK", k);
        }
        else
        {
            sprintf(str, "%dK%d", k, decimal);
        }
    }
    else
    {
        sprintf(str, "%dK", (int)(freq / 1000));
    }
}

void UI_FormatVoltage(char *str, float voltage)
{
    sprintf(str, "%.1f", voltage);
}

void UI_FormatPhase(char *str, float phase_deg)
{
    if (phase_deg >= 0)
    {
        sprintf(str, "+%d", (int)phase_deg);
    }
    else
    {
        sprintf(str, "%d", (int)phase_deg);
    }
}

/******************** �˵��л����� ********************/

void UI_EnterMenu1(void)
{
    ui_param.state = UI_STATE_MENU1;
    ui_param.current_select = SELECT_WAVE1_TYPE;
    ui_param.is_editing = 0;
    UI_DrawMenu1();
}

void UI_ExitMenu1(void)
{
    ui_param.state = UI_STATE_IDLE;
    OLED_Clear();
    OLED_Update();
}

void UI_EnterMenu2(void)
{
    ui_param.state = UI_STATE_MENU2;
    ui_param.scope_param.is_running = 1;
    ui_param.scope_param.show_multiply = 0;
    ui_param.scope_param.wave_select = WAVE_SELECT_NONE;
    ui_param.scope_param.phase_editing = 0;
    ui_param.scope_param.timebase_index = 4;
    
    DAC_OutputWaves(&ui_param.wave1_config, &ui_param.wave2_config);
    ADC_SwitchMode(0);
    
    UI_DrawMenu2();
}

/******************** ����ѡ�����λ�������� ********************/

void UI_SelectWave(WaveSelect wave)
{
    if (ui_param.scope_param.wave_select == wave)
    {
        ui_param.scope_param.wave_select = WAVE_SELECT_NONE;
        ui_param.scope_param.phase_editing = 0;
    }
    else
    {
        ui_param.scope_param.wave_select = wave;
        ui_param.scope_param.phase_editing = 0;
    }
}

void UI_TogglePhaseEdit(void)
{
    if (ui_param.scope_param.wave_select != WAVE_SELECT_NONE &&
        ui_param.scope_param.wave_select != WAVE_SELECT_CH3)
    {
        ui_param.scope_param.phase_editing = !ui_param.scope_param.phase_editing;
    }
}

void UI_AdjustPhaseIncrease(void)
{
    if (!ui_param.scope_param.phase_editing)
        return;
    
    if (ui_param.scope_param.wave_select == WAVE_SELECT_CH1)
    {
        ui_param.wave1_config.phase += 15;
        if (ui_param.wave1_config.phase > 180)
            ui_param.wave1_config.phase = -180 + (ui_param.wave1_config.phase - 180);
        
        DAC_OutputWaves(&ui_param.wave1_config, &ui_param.wave2_config);
    }
    else if (ui_param.scope_param.wave_select == WAVE_SELECT_CH2)
    {
        ui_param.wave2_config.phase += 15;
        if (ui_param.wave2_config.phase > 180)
            ui_param.wave2_config.phase = -180 + (ui_param.wave2_config.phase - 180);
        
        DAC_OutputWaves(&ui_param.wave1_config, &ui_param.wave2_config);
    }
}

void UI_AdjustPhaseDecrease(void)
{
    if (!ui_param.scope_param.phase_editing)
        return;
    
    if (ui_param.scope_param.wave_select == WAVE_SELECT_CH1)
    {
        ui_param.wave1_config.phase -= 15;
        if (ui_param.wave1_config.phase < -180)
            ui_param.wave1_config.phase = 180 - ((-180) - ui_param.wave1_config.phase);
        
        DAC_OutputWaves(&ui_param.wave1_config, &ui_param.wave2_config);
    }
    else if (ui_param.scope_param.wave_select == WAVE_SELECT_CH2)
    {
        ui_param.wave2_config.phase -= 15;
        if (ui_param.wave2_config.phase < -180)
            ui_param.wave2_config.phase = 180 - ((-180) - ui_param.wave2_config.phase);
        
        DAC_OutputWaves(&ui_param.wave1_config, &ui_param.wave2_config);
    }
}

/******************** ѡ��ͱ༭���� ********************/

void UI_SelectNext(void)
{
    if (!ui_param.is_editing)
    {
        ui_param.current_select = (SelectPos)((ui_param.current_select + 1) % SELECT_MAX);
        
        if (ui_param.current_select >= SELECT_WAVE1_PHASE)
        {
            UI_DrawMenu1_Scroll();
        }
        else
        {
            UI_DrawMenu1();
        }
    }
}

void UI_SelectPrev(void)
{
    if (!ui_param.is_editing)
    {
        if (ui_param.current_select == 0)
            ui_param.current_select = (SelectPos)(SELECT_MAX - 1);
        else
            ui_param.current_select = (SelectPos)(ui_param.current_select - 1);
        
        if (ui_param.current_select >= SELECT_WAVE1_PHASE)
        {
            UI_DrawMenu1_Scroll();
        }
        else
        {
            UI_DrawMenu1();
        }
    }
}

void UI_IncreaseValue(void)
{
    uint8_t i;
    
    if (!ui_param.is_editing) return;
    
    switch(ui_param.current_select)
    {
        case SELECT_WAVE1_TYPE:
            ui_param.wave1_config.type = (WaveType)((ui_param.wave1_config.type + 1) % WAVE_TYPE_MAX);
            break;
            
        case SELECT_WAVE2_TYPE:
            ui_param.wave2_config.type = (WaveType)((ui_param.wave2_config.type + 1) % WAVE_TYPE_MAX);
            break;
            
        case SELECT_WAVE1_FREQ:
            for (i = 0; i < freq_options_count - 1; i++)
            {
                if (ui_param.wave1_config.freq == freq_options[i])
                {
                    ui_param.wave1_config.freq = freq_options[i + 1];
                    break;
                }
            }
            break;
            
        case SELECT_WAVE2_FREQ:
            for (i = 0; i < freq_options_count - 1; i++)
            {
                if (ui_param.wave2_config.freq == freq_options[i])
                {
                    ui_param.wave2_config.freq = freq_options[i + 1];
                    break;
                }
            }
            break;
            
        case SELECT_WAVE1_AMP:
            for (i = 0; i < amp_options_count - 1; i++)
            {
                if (ui_param.wave1_config.amplitude == amp_options[i])
                {
                    ui_param.wave1_config.amplitude = amp_options[i + 1];
                    break;
                }
            }
            break;
            
        case SELECT_WAVE2_AMP:
            for (i = 0; i < amp_options_count - 1; i++)
            {
                if (ui_param.wave2_config.amplitude == amp_options[i])
                {
                    ui_param.wave2_config.amplitude = amp_options[i + 1];
                    break;
                }
            }
            break;
            
        case SELECT_WAVE1_PHASE:
            ui_param.wave1_config.phase += 15;
            if (ui_param.wave1_config.phase > 180)
                ui_param.wave1_config.phase = -180 + (ui_param.wave1_config.phase - 180);
            break;
            
        case SELECT_WAVE2_PHASE:
            ui_param.wave2_config.phase += 15;
            if (ui_param.wave2_config.phase > 180)
                ui_param.wave2_config.phase = -180 + (ui_param.wave2_config.phase - 180);
            break;
            
        default:
            break;
    }
    
    if (ui_param.current_select >= SELECT_WAVE1_PHASE)
    {
        UI_DrawMenu1_Scroll();
    }
    else
    {
        UI_DrawMenu1();
    }
}

void UI_DecreaseValue(void)
{
    uint8_t i;
    
    if (!ui_param.is_editing) return;
    
    switch(ui_param.current_select)
    {
        case SELECT_WAVE1_TYPE:
            if (ui_param.wave1_config.type == 0)
                ui_param.wave1_config.type = (WaveType)(WAVE_TYPE_MAX - 1);
            else
                ui_param.wave1_config.type = (WaveType)(ui_param.wave1_config.type - 1);
            break;
            
        case SELECT_WAVE2_TYPE:
            if (ui_param.wave2_config.type == 0)
                ui_param.wave2_config.type = (WaveType)(WAVE_TYPE_MAX - 1);
            else
                ui_param.wave2_config.type = (WaveType)(ui_param.wave2_config.type - 1);
            break;
            
        case SELECT_WAVE1_FREQ:
            for (i = 1; i < freq_options_count; i++)
            {
                if (ui_param.wave1_config.freq == freq_options[i])
                {
                    ui_param.wave1_config.freq = freq_options[i - 1];
                    break;
                }
            }
            break;
            
        case SELECT_WAVE2_FREQ:
            for (i = 1; i < freq_options_count; i++)
            {
                if (ui_param.wave2_config.freq == freq_options[i])
                {
                    ui_param.wave2_config.freq = freq_options[i - 1];
                    break;
                }
            }
            break;
            
        case SELECT_WAVE1_AMP:
            for (i = 1; i < amp_options_count; i++)
            {
                if (ui_param.wave1_config.amplitude == amp_options[i])
                {
                    ui_param.wave1_config.amplitude = amp_options[i - 1];
                    break;
                }
            }
            break;
            
        case SELECT_WAVE2_AMP:
            for (i = 1; i < amp_options_count; i++)
            {
                if (ui_param.wave2_config.amplitude == amp_options[i])
                {
                    ui_param.wave2_config.amplitude = amp_options[i - 1];
                    break;
                }
            }
            break;
            
        case SELECT_WAVE1_PHASE:
            ui_param.wave1_config.phase -= 15;
            if (ui_param.wave1_config.phase < -180)
                ui_param.wave1_config.phase = 180 - ((-180) - ui_param.wave1_config.phase);
            break;
            
        case SELECT_WAVE2_PHASE:
            ui_param.wave2_config.phase -= 15;
            if (ui_param.wave2_config.phase < -180)
                ui_param.wave2_config.phase = 180 - ((-180) - ui_param.wave2_config.phase);
            break;
            
        default:
            break;
    }
    
    if (ui_param.current_select >= SELECT_WAVE1_PHASE)
    {
        UI_DrawMenu1_Scroll();
    }
    else
    {
        UI_DrawMenu1();
    }
}

void UI_ConfirmEdit(void)
{
    ui_param.is_editing = !ui_param.is_editing;
    
    if (ui_param.current_select >= SELECT_WAVE1_PHASE)
    {
        UI_DrawMenu1_Scroll();
    }
    else
    {
        UI_DrawMenu1();
    }
}

/******************** �������� ********************/

void UI_ToggleMenu1Scroll(void)
{
    if (ui_param.current_select < SELECT_WAVE1_PHASE)
    {
        ui_param.current_select = SELECT_WAVE1_PHASE;
        UI_DrawMenu1_Scroll();
    }
    else
    {
        ui_param.current_select = SELECT_WAVE1_TYPE;
        UI_DrawMenu1();
    }
}

void UI_ToggleMenu2Scroll(void)
{
    ui_param.scope_param.show_multiply = !ui_param.scope_param.show_multiply;
    
    ui_param.scope_param.wave_select = WAVE_SELECT_NONE;
    ui_param.scope_param.phase_editing = 0;
    
    if (ui_param.scope_param.show_multiply)
    {
        UI_DrawMenu2_Multiply();
    }
    else
    {
        UI_DrawMenu2();
    }
}

/******************** ʾ������غ��� ********************/

void UI_Scope_IncreaseTimeBase(void)
{
    if (ui_param.scope_param.timebase_index < 9)
    {
        ui_param.scope_param.timebase_index++;
    }
}

void UI_Scope_DecreaseTimeBase(void)
{
    if (ui_param.scope_param.timebase_index > 0)
    {
        ui_param.scope_param.timebase_index--;
    }
}

void UI_Scope_ToggleRunStop(void)
{
    ui_param.scope_param.is_running = !ui_param.scope_param.is_running;
    
    if (!ui_param.scope_param.is_running)
    {
        uint16_t i;
        for (i = 0; i < ADC_BUFFER_SIZE; i++)
        {
            frozen_ch1[i] = ADC_Value[0][i];
            frozen_ch2[i] = ADC_Value[1][i];
        }
    }
}

void UI_Scope_UpdateMeasure(void)
{
    Scope_ADC_CalculateParams_CH1(&ui_param.scope_param.ch1_freq, 
                                  &ui_param.scope_param.ch1_vpp);
    
    Scope_ADC_CalculateParams_CH2(&ui_param.scope_param.ch2_freq, 
                                  &ui_param.scope_param.ch2_vpp);
}

void UI_Scope_UpdatePhase(void)
{
    Scope_ADC_GetPhaseInfo(&ui_param.scope_param.phase_diff_deg,
                           &ui_param.scope_param.phase_diff_rad,
                           &ui_param.scope_param.phase_valid);
}

uint16_t UI_Scope_GetSampleStep(void)
{
    uint8_t index = ui_param.scope_param.timebase_index;
    
    const uint16_t step_table[10] = {
        1, 2, 4, 8, 16, 32, 64, 128, 256, 512
    };
    
    return step_table[index];
}

/******************** �˵����ƺ��� ********************/
/// �滻 UI_DrawMenu1() ����
void UI_DrawMenu1(void)
{
    char str[20];
    int16_t col, row;
    uint8_t is_selected, is_editing_this;
    uint8_t cell_width = 45;  // 78-33=45, 127-78=49
    uint8_t cell_height = 16;
    
    OLED_Clear();
    
    // ���Ʒָ���
    OLED_DrawLine(0, 16, 127, 16);
    OLED_DrawLine(0, 32, 127, 32);
    OLED_DrawLine(0, 48, 127, 48);
    OLED_DrawLine(33, 0, 33, 63);
    OLED_DrawLine(78, 0, 78, 63);
    
    // ��һ�б��⣺�ź�1 / �ź�2 (�п�: 34-77=44px, 79-127=49px)
    OLED_ShowString(38, 2, "�ź�", OLED_12X12);
	  OLED_ShowString(63, 0, "1", OLED_8X16);
    OLED_ShowString(83, 2, "�ź�", OLED_12X12);
		OLED_ShowString(106, 0, "2", OLED_8X16);
	
    
    // �ڶ��У����� (Y: 17-31)
    OLED_ShowString(1, 17, "����", OLED_12X12);
    
    // �ź�1����
    col = 34; row = 17;
    is_selected = (ui_param.current_select == SELECT_WAVE1_TYPE && !ui_param.is_editing);
    is_editing_this = (ui_param.current_select == SELECT_WAVE1_TYPE && ui_param.is_editing);
    OLED_ShowString(col + 2, row, (char*)UI_GetWaveTypeName_CN(ui_param.wave1_config.type), OLED_12X12);
    if (is_editing_this) OLED_ShowString(col + 38, row + 4, "*", OLED_6X8);
    if (is_selected) OLED_ReverseArea(col, row, cell_width - 1, cell_height - 1);
    
    // �ź�2����
    col = 79;
    is_selected = (ui_param.current_select == SELECT_WAVE2_TYPE && !ui_param.is_editing);
    is_editing_this = (ui_param.current_select == SELECT_WAVE2_TYPE && ui_param.is_editing);
    OLED_ShowString(col + 2, row, (char*)UI_GetWaveTypeName_CN(ui_param.wave2_config.type), OLED_12X12);
    if (is_editing_this) OLED_ShowString(col + 42, row + 4, "*", OLED_6X8);
    if (is_selected) OLED_ReverseArea(col, row, 48, cell_height - 1);
    
    // �����У�Ƶ�� (Y: 33-47)
    OLED_ShowString(1, 33, "Ƶ��", OLED_12X12);
    
    // �ź�1Ƶ��
    col = 34; row = 33;
    is_selected = (ui_param.current_select == SELECT_WAVE1_FREQ && !ui_param.is_editing);
    is_editing_this = (ui_param.current_select == SELECT_WAVE1_FREQ && ui_param.is_editing);
    sprintf(str, "%dHz", (int)ui_param.wave1_config.freq);
    OLED_ShowString(col + 4, row + 4, str, OLED_6X8);
    if (is_editing_this) OLED_ShowString(col + 38, row + 4, "*", OLED_6X8);
    if (is_selected) OLED_ReverseArea(col, row, cell_width - 1, cell_height - 1);
    
    // �ź�2Ƶ��
    col = 79;
    is_selected = (ui_param.current_select == SELECT_WAVE2_FREQ && !ui_param.is_editing);
    is_editing_this = (ui_param.current_select == SELECT_WAVE2_FREQ && ui_param.is_editing);
    sprintf(str, "%dHz", (int)ui_param.wave2_config.freq);
    OLED_ShowString(col + 4, row + 4, str, OLED_6X8);
    if (is_editing_this) OLED_ShowString(col + 42, row + 4, "*", OLED_6X8);
    if (is_selected) OLED_ReverseArea(col, row, 48, cell_height - 1);
    
    // �����У���ֵ (Y: 49-63)
    OLED_ShowString(1, 49, "����", OLED_12X12);
    
    // �ź�1��ֵ
    col = 34; row = 49;
    is_selected = (ui_param.current_select == SELECT_WAVE1_AMP && !ui_param.is_editing);
    is_editing_this = (ui_param.current_select == SELECT_WAVE1_AMP && ui_param.is_editing);
    sprintf(str, "%.1fV", ui_param.wave1_config.amplitude);
    OLED_ShowString(col + 8, row + 4, str, OLED_6X8);
    if (is_editing_this) OLED_ShowString(col + 38, row + 4, "*", OLED_6X8);
    if (is_selected) OLED_ReverseArea(col, row, cell_width - 1, cell_height - 1);
    
    // �ź�2��ֵ
    col = 79;
    is_selected = (ui_param.current_select == SELECT_WAVE2_AMP && !ui_param.is_editing);
    is_editing_this = (ui_param.current_select == SELECT_WAVE2_AMP && ui_param.is_editing);
    sprintf(str, "%.1fV", ui_param.wave2_config.amplitude);
    OLED_ShowString(col + 8, row + 4, str, OLED_6X8);
    if (is_editing_this) OLED_ShowString(col + 42, row + 4, "*", OLED_6X8);
    if (is_selected) OLED_ReverseArea(col, row, 48, cell_height - 1);
    
    OLED_Update();
}

// �滻 UI_DrawMenu1_Scroll() ����
void UI_DrawMenu1_Scroll(void)
{
    char str[20];
    int16_t col, row;
    uint8_t is_selected, is_editing_this;
    uint8_t cell_width = 45;
    uint8_t cell_height = 16;
    
    OLED_Clear();
    
    // ���Ʒָ���
    OLED_DrawLine(0, 16, 127, 16);
    OLED_DrawLine(0, 32, 127, 32);
    OLED_DrawLine(0, 48, 127, 48);
    OLED_DrawLine(33, 0, 33, 63);
    OLED_DrawLine(78, 0, 78, 63);
    
    // ��һ�б���
    OLED_ShowString(38, 2, "�ź�", OLED_12X12);
	  OLED_ShowString(63, 0, "1", OLED_8X16);
    OLED_ShowString(83, 2, "�ź�", OLED_12X12);
		OLED_ShowString(106, 0, "2", OLED_8X16);
    
    // �ڶ��У�Ƶ�� (Y: 17-31)
    OLED_ShowString(1, 17, "Ƶ��", OLED_12X12);
    
    col = 34; row = 17;
    sprintf(str, "%dHz", (int)ui_param.wave1_config.freq);
    OLED_ShowString(col + 4, row + 4, str, OLED_6X8);
    
    col = 79;
    sprintf(str, "%dHz", (int)ui_param.wave2_config.freq);
    OLED_ShowString(col + 4, row + 4, str, OLED_6X8);
    
    // �����У���ֵ (Y: 33-47)
    OLED_ShowString(1, 33, "����", OLED_12X12);
    
    col = 34; row = 33;
    sprintf(str, "%.1fV", ui_param.wave1_config.amplitude);
    OLED_ShowString(col + 8, row + 4, str, OLED_6X8);
    
    col = 79;
    sprintf(str, "%.1fV", ui_param.wave2_config.amplitude);
    OLED_ShowString(col + 8, row + 4, str, OLED_6X8);
    
    // �����У���λ (Y: 49-63)
    OLED_ShowString(1, 49, "��λ", OLED_12X12);
    
    // �ź�1��λ
    col = 34; row = 49;
    is_selected = (ui_param.current_select == SELECT_WAVE1_PHASE && !ui_param.is_editing);
    is_editing_this = (ui_param.current_select == SELECT_WAVE1_PHASE && ui_param.is_editing);
    UI_FormatPhase(str, ui_param.wave1_config.phase);
    OLED_ShowString(col + 6, row + 4, str, OLED_6X8);
    if (is_editing_this) OLED_ShowString(col + 38, row + 4, "*", OLED_6X8);
    if (is_selected) OLED_ReverseArea(col, row, cell_width - 1, cell_height - 1);
    
    // �ź�2��λ
    col = 79;
    is_selected = (ui_param.current_select == SELECT_WAVE2_PHASE && !ui_param.is_editing);
    is_editing_this = (ui_param.current_select == SELECT_WAVE2_PHASE && ui_param.is_editing);
    UI_FormatPhase(str, ui_param.wave2_config.phase);
    OLED_ShowString(col + 6, row + 4, str, OLED_6X8);
    if (is_editing_this) OLED_ShowString(col + 42, row + 4, "*", OLED_6X8);
    if (is_selected) OLED_ReverseArea(col, row, 48, cell_height - 1);
    
    OLED_Update();
}



/**
  * ��������: ���ƶ����˵� - ˫·ʾ����
  * ˵    ��: �����Ƿ�ѡ�в��Σ���ʾ��ͬ����
  *          - δѡ�л�ѡ�е�δ�༭����ʾ������Ƶ�ʺͷ��ֵ
  *          - ѡ�в��༭��λ����ʾ���õ���λ����
  */
/**
  * ��������: ���ƶ����˵� - ˫·ʾ����
  * ˵    ��: ��λ�༭ģʽ��һ����ʾ����ͨ������λ����
  */
void UI_DrawMenu2(void)
{
    uint16_t i, y1, y2;
    char str[16];
    float voltage;
    uint16_t step;
    uint8_t x_pos = 0;
    
    OLED_Clear();
    
    // ===== ��1�У������Ƿ�༭��λ��ʾ��ͬ���� =====
    if (ui_param.scope_param.wave_select != WAVE_SELECT_NONE && 
        ui_param.scope_param.phase_editing)
    {
        // **��λ�༭ģʽ��һ����ʾ����ͨ����������λ**
        OLED_ShowString(0, 0, "Ph1:", OLED_6X8);
        UI_FormatPhase(str, ui_param.wave1_config.phase);
        OLED_ShowString(24, 0, str, OLED_6X8);
        OLED_ShowString(42, 0, "deg", OLED_6X8);
        
        // �ָ���
        OLED_ShowString(60, 0, "#", OLED_6X8);
        
        // CH2��λ
        OLED_ShowString(66, 0, "Ph2:", OLED_6X8);
        UI_FormatPhase(str, ui_param.wave2_config.phase);
        OLED_ShowString(90, 0, str, OLED_6X8);
        OLED_ShowString(108, 0, "deg", OLED_6X8);
        
        // ��ʾ����״̬�����Ͻǣ�
        if (ui_param.scope_param.is_running)
        {
            OLED_ShowString(122, 0, "R", OLED_6X8);
        }
        else
        {
            OLED_ShowString(122, 0, "S", OLED_6X8);
        }
    }
    else
    {
        // **����ģʽ����ʾ������Ƶ�ʺͷ��ֵ**
        // CH1Ƶ�ʺͷ���
        UI_FormatFreq(str, ui_param.scope_param.ch1_freq);
        OLED_ShowString(x_pos, 0, str, OLED_6X8);
        x_pos += strlen(str) * 6;
        
        OLED_ShowString(x_pos, 0, " ", OLED_6X8);
        x_pos += 6;
        
        UI_FormatVoltage(str, ui_param.scope_param.ch1_vpp);
        OLED_ShowString(x_pos, 0, str, OLED_6X8);
        x_pos += strlen(str) * 6;
        OLED_ShowString(x_pos, 0, "V", OLED_6X8);
        x_pos += 6;
        
        OLED_ShowString(x_pos, 0, " # ", OLED_6X8);
        x_pos += 18;
        
        // CH2Ƶ�ʺͷ���
        UI_FormatFreq(str, ui_param.scope_param.ch2_freq);
        OLED_ShowString(x_pos, 0, str, OLED_6X8);
        x_pos += strlen(str) * 6;
        
        OLED_ShowString(x_pos, 0, " ", OLED_6X8);
        x_pos += 6;
        
        UI_FormatVoltage(str, ui_param.scope_param.ch2_vpp);
        OLED_ShowString(x_pos, 0, str, OLED_6X8);
        x_pos += strlen(str) * 6;
        OLED_ShowString(x_pos, 0, "V", OLED_6X8);
        x_pos += 6;
        
        // ��ʾ����״̬
        if (ui_param.scope_param.is_running)
        {
            OLED_ShowString(122, 0, "R", OLED_6X8);
        }
        else
        {
            OLED_ShowString(122, 0, "S", OLED_6X8);
        }
    }
    
    // ===== �������� =====
    OLED_DrawLine(0, 32, 127, 32);
    
    for (i = 0; i <= 127; i += 25)
    {
        OLED_DrawPoint(i, 30);
        OLED_DrawPoint(i, 32);
        OLED_DrawPoint(i, 34);
    }
    
    // ===== ���Ʋ��� =====
    step = UI_Scope_GetSampleStep();
    
    for (i = 0; i < 127; i++)
    {
        uint16_t sample_index = (uint32_t)i * step;
        
        if (sample_index >= ADC_BUFFER_SIZE)
            sample_index = ADC_BUFFER_SIZE - 1;
        
        // CH1���Σ��ϰ벿�֣�
        if (ui_param.scope_param.is_running)
        {
            voltage = ADC_GetVoltage_CH1(sample_index);
        }
        else
        {
            voltage = (float)frozen_ch1[sample_index] * 3.3f / 4095.0f;
        }
        
        y1 = 32 - (uint16_t)(voltage * 24.0f / 3.3f);
        if (y1 < 8) y1 = 8;
        if (y1 > 32) y1 = 32;
        
        OLED_DrawPoint(i, y1);
        
        if (i > 0)
        {
            uint16_t last_index = (uint32_t)(i - 1) * step;
            if (last_index >= ADC_BUFFER_SIZE)
                last_index = ADC_BUFFER_SIZE - 1;
            
            float last_voltage;
            if (ui_param.scope_param.is_running)
            {
                last_voltage = ADC_GetVoltage_CH1(last_index);
            }
            else
            {
                last_voltage = (float)frozen_ch1[last_index] * 3.3f / 4095.0f;
            }
            
            uint16_t last_y1 = 32 - (uint16_t)(last_voltage * 24.0f / 3.3f);
            if (last_y1 < 8) last_y1 = 8;
            if (last_y1 > 32) last_y1 = 32;
            
            if (abs(y1 - last_y1) < 8)
            {
                OLED_DrawLine(i - 1, last_y1, i, y1);
            }
        }
        
        // CH2���Σ��°벿�֣�
        if (ui_param.scope_param.is_running)
        {
            voltage = ADC_GetVoltage_CH2(sample_index);
        }
        else
        {
            voltage = (float)frozen_ch2[sample_index] * 3.3f / 4095.0f;
        }
        
        y2 = 56 - (uint16_t)(voltage * 24.0f / 3.3f);
        if (y2 < 32) y2 = 32;
        if (y2 > 56) y2 = 56;
        
        OLED_DrawPoint(i, y2);
        
        if (i > 0)
        {
            uint16_t last_index = (uint32_t)(i - 1) * step;
            if (last_index >= ADC_BUFFER_SIZE)
                last_index = ADC_BUFFER_SIZE - 1;
            
            float last_voltage;
            if (ui_param.scope_param.is_running)
            {
                last_voltage = ADC_GetVoltage_CH2(last_index);
            }
            else
            {
                last_voltage = (float)frozen_ch2[last_index] * 3.3f / 4095.0f;
            }
            
            uint16_t last_y2 = 56 - (uint16_t)(last_voltage * 24.0f / 3.3f);
            if (last_y2 < 32) last_y2 = 32;
            if (last_y2 > 56) last_y2 = 56;
            
            if (abs(y2 - last_y2) < 8)
            {
                OLED_DrawLine(i - 1, last_y2, i, y2);
            }
        }
    }
    
    // ��ǩ������ѡ��״̬��ɫ��
    if (ui_param.scope_param.wave_select == WAVE_SELECT_CH1)
    {
        if (ui_param.scope_param.phase_editing)
        {
            OLED_ShowString(0, 16, "1*", OLED_6X8);
        }
        else
        {
            OLED_ShowString(0, 16, "1", OLED_6X8);
        }
        OLED_ReverseArea(0, 16, 11, 7);
    }
    else
    {
        OLED_ShowString(0, 16, "1", OLED_6X8);
    }
    
    if (ui_param.scope_param.wave_select == WAVE_SELECT_CH2)
    {
        if (ui_param.scope_param.phase_editing)
        {
            OLED_ShowString(0, 40, "2*", OLED_6X8);
        }
        else
        {
            OLED_ShowString(0, 40, "2", OLED_6X8);
        }
        OLED_ReverseArea(0, 40, 11, 7);
    }
    else
    {
        OLED_ShowString(0, 40, "2", OLED_6X8);
    }
}
void UI_DrawMenu2_Multiply(void)
{
    uint16_t i;
    int16_t y3;  // ��Ϊ�з�������??��������м������
    char str[16];
    float voltage1, voltage2, voltage_mul;
    uint16_t step;
    float max_mul = 0, min_mul = 100.0f;  // min_mul��ʼֵ�Ĵ�
    
    OLED_Clear();
    
    // ===== ��1�� =====
    OLED_ShowString(0, 0, "CH1*CH2", OLED_6X8);
    
    // ��ʾ��λ
    OLED_ShowString(48, 0, "Ph:", OLED_6X8);
    UI_FormatPhase(str, ui_param.wave1_config.phase);
    OLED_ShowString(66, 0, str, OLED_6X8);
    
    OLED_ShowString(85, 0, "/", OLED_6X8);
    
    UI_FormatPhase(str, ui_param.wave2_config.phase);
    OLED_ShowString(90, 0, str, OLED_6X8);
    
    // ��ʾ����״̬
    if (ui_param.scope_param.is_running)
    {
        OLED_ShowString(122, 0, "R", OLED_6X8);
    }
    else
    {
        OLED_ShowString(122, 0, "S", OLED_6X8);
    }
    
    // ===== ���Ļ��� =====
    OLED_DrawLine(0, 32, 127, 32);
    
    for (i = 0; i <= 127; i += 25)
    {
        OLED_DrawPoint(i, 30);
        OLED_DrawPoint(i, 32);
        OLED_DrawPoint(i, 34);
    }
    
    // ===== ��һ�飺�ҳ������Сֵ =====
    step = UI_Scope_GetSampleStep();
    
    for (i = 0; i < 128; i++)
    {
        uint16_t sample_index = (uint32_t)i * step;
        
        // ��ֹ����Խ��
        if (sample_index >= ADC_BUFFER_SIZE)
            sample_index = ADC_BUFFER_SIZE - 1;
        
        if (ui_param.scope_param.is_running)
        {
            voltage1 = ADC_GetVoltage_CH1(sample_index);
            voltage2 = ADC_GetVoltage_CH2(sample_index);
        }
        else
        {
            voltage1 = (float)frozen_ch1[sample_index] * 3.3f / 4095.0f;
            voltage2 = (float)frozen_ch2[sample_index] * 3.3f / 4095.0f;
        }
        
        voltage_mul = voltage1 * voltage2;
        
        if (voltage_mul > max_mul) max_mul = voltage_mul;
        if (voltage_mul < min_mul) min_mul = voltage_mul;
    }
    
    // ��������ϵ������ֹ���㣩
    float range = max_mul - min_mul;
    if (range < 0.01f) range = 0.01f;  // ��ֹrange��С
    
    float scale = 40.0f / range;  // ������ʾ�߶�40���أ�12-52��
    float offset = (max_mul + min_mul) / 2.0f;
    
    // ����scale��ֹ����
    if (scale > 100.0f) scale = 100.0f;
    
    // ===== �ڶ��飺���Ʋ��� =====
    int16_t last_y3 = 32;  // ������һ�����Y����
    uint8_t first_point = 1;
    
    for (i = 0; i < 128; i++)  // ��Ϊ128�����һ��һ��
    {
        uint16_t sample_index = (uint32_t)i * step;
        
        // ��ֹ����Խ��
        if (sample_index >= ADC_BUFFER_SIZE)
            sample_index = ADC_BUFFER_SIZE - 1;
        
        if (ui_param.scope_param.is_running)
        {
            voltage1 = ADC_GetVoltage_CH1(sample_index);
            voltage2 = ADC_GetVoltage_CH2(sample_index);
        }
        else
        {
            voltage1 = (float)frozen_ch1[sample_index] * 3.3f / 4095.0f;
            voltage2 = (float)frozen_ch2[sample_index] * 3.3f / 4095.0f;
        }
        
        voltage_mul = voltage1 * voltage2;
        
        // ����Y���꣨ʹ���з������㣩
        float y_offset_f = (voltage_mul - offset) * scale;
        
        // ����y_offset��Χ����ֹ���
        if (y_offset_f > 24.0f) y_offset_f = 24.0f;
        if (y_offset_f < -24.0f) y_offset_f = -24.0f;
        
        y3 = 32 - (int16_t)y_offset_f;
        
        // ����Y��������Ч��ʾ��Χ�ڣ�8-56��
        if (y3 < 8) y3 = 8;
        if (y3 > 56) y3 = 56;
        
        // ���Ƶ�ǰ��
        OLED_DrawPoint(i, y3);
        
        // ���ߣ������һ�������ߴ���
        if (!first_point)
        {
            // ֻ�����ڵ�Y��಻��ʱ�����ߣ����ⴹֱ��
            if (abs(y3 - last_y3) <= 12)
            {
                OLED_DrawLine(i - 1, last_y3, i, y3);
            }
        }
        
        first_point = 0;
        last_y3 = y3;
    }
    
    // ��ǩ
    if (ui_param.scope_param.wave_select == WAVE_SELECT_CH3)
    {
        OLED_ShowString(0, 28, "3", OLED_6X8);
        OLED_ReverseArea(0, 28, 5, 7);
    }
    else
    {
        OLED_ShowString(0, 28, "3", OLED_6X8);
    }
}


/******************** UI�¼����� ********************/

void UI_Handle(void)
{
    EC11_Event event = EC11_GetEvent();
    
    if (ui_param.state == UI_STATE_IDLE)
    {
        EC11_ClearEvent();
        return;
    }
    
    if (ui_param.state == UI_STATE_MENU1)
    {
        switch(event)
        {
            case CW:
                if (ui_param.is_editing)
                    UI_IncreaseValue();
                else
                    UI_SelectNext();
                EC11_ClearEvent();
                break;
                
            case CCW:
                if (ui_param.is_editing)
                    UI_DecreaseValue();
                else
                    UI_SelectPrev();
                EC11_ClearEvent();
                break;
                
            case PRESS_DOWN:
                EC11_ClearEvent();
                break;
                
            default:
                break;
        }
    }
    else if (ui_param.state == UI_STATE_MENU2)
    {
        switch(event)
        {
            case CW:
                if (ui_param.scope_param.phase_editing)
                {
                    UI_AdjustPhaseIncrease();
                }
                else
                {
                    UI_Scope_IncreaseTimeBase();
                }
                EC11_ClearEvent();
                break;
                
            case CCW:
                if (ui_param.scope_param.phase_editing)
                {
                    UI_AdjustPhaseDecrease();
                }
                else
                {
                    UI_Scope_DecreaseTimeBase();
                }
                EC11_ClearEvent();
                break;
                
            case PRESS_DOWN:
                UI_Scope_ToggleRunStop();
                EC11_ClearEvent();
                break;
                
            default:
                break;
        }
    }
}

void UI_Draw(void)
{
    switch(ui_param.state)
    {
        case UI_STATE_IDLE:
            break;
            
        case UI_STATE_MENU1:
            if (ui_param.current_select >= SELECT_WAVE1_PHASE)
            {
                UI_DrawMenu1_Scroll();
            }
            else
            {
                UI_DrawMenu1();
            }
            break;
            
        case UI_STATE_MENU2:
            if (ui_param.scope_param.show_multiply)
            {
                UI_DrawMenu2_Multiply();
            }
            else
            {
                UI_DrawMenu2();
            }
            break;
            
        default:
            break;
    }
}



