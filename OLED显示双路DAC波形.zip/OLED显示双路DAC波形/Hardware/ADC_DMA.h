#ifndef __ADC_DMA_H
#define __ADC_DMA_H

#include "stm32f10x.h"

/******************** ADC���ò��� ********************/
#define ADC_BUFFER_SIZE     2048     // ADC DMA��������С
#define ADC_CHANNEL_NUM     2        // ADCͨ������

// ADCͨ������
#define ADC_CH0_GPIO_PORT   GPIOA
#define ADC_CH0_GPIO_PIN    GPIO_Pin_0
#define ADC_CH0_CHANNEL     ADC_Channel_0

#define ADC_CH1_GPIO_PORT   GPIOA
#define ADC_CH1_GPIO_PIN    GPIO_Pin_1
#define ADC_CH1_CHANNEL     ADC_Channel_1

/******************** ȫ�ֱ������� ********************/
extern uint16_t ADC_Value_Raw[ADC_BUFFER_SIZE * ADC_CHANNEL_NUM];
extern uint16_t ADC_Value[ADC_CHANNEL_NUM][ADC_BUFFER_SIZE];
extern uint16_t Scope_ADC_Value[ADC_BUFFER_SIZE];

/******************** �������� ********************/
void ADC_DMA_Init(void);
void ADC_Deinterleave(void);
uint16_t ADC_GetValue(uint8_t channel, uint16_t index);
float ADC_GetVoltage(uint8_t channel, uint16_t index);

void Scope_ADC_Init(void);
void Scope_ADC_Start(void);
void Scope_ADC_Stop(void);
uint16_t Scope_ADC_GetValue(uint16_t index);
float Scope_ADC_GetVoltage(uint16_t index);
void Scope_ADC_CalculateParams(float *freq, float *vpp);

void Scope_ADC_CalculateParams_CH1(float *freq, float *vpp);
void Scope_ADC_CalculateParams_CH2(float *freq, float *vpp);
float ADC_GetVoltage_CH1(uint16_t index);
float ADC_GetVoltage_CH2(uint16_t index);

float Scope_ADC_CalculatePhase_CH1_CH2(void);
void Scope_ADC_GetPhaseInfo(float *phase_deg, float *phase_rad, uint8_t *is_valid);

void ADC_SwitchMode(uint8_t mode);

#endif


