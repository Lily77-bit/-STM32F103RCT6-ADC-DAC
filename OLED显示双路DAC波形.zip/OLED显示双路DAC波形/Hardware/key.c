#include "KEY.h"
#include "Timer.h"

// ������־λ
static uint8_t key0_flag = 0;
static uint8_t key1_flag = 0;
static uint8_t key0_long_flag = 0;
static uint8_t key1_long_flag = 0;

// OLED������־λ
static uint8_t oled_key1_flag = 0;
static uint8_t oled_key2_flag = 0;
static uint8_t oled_key3_flag = 0;
static uint8_t oled_key4_flag = 0;

// ����״̬
static KEY_State key0_state = KEY_STATE_IDLE;
static KEY_State key1_state = KEY_STATE_IDLE;
static KEY_State oled_key1_state = KEY_STATE_IDLE;
static KEY_State oled_key2_state = KEY_STATE_IDLE;
static KEY_State oled_key3_state = KEY_STATE_IDLE;
static KEY_State oled_key4_state = KEY_STATE_IDLE;

// ��������ʱ��
static uint32_t key0_press_time = 0;
static uint32_t key1_press_time = 0;

/******************************************************************************
 * ��������: KEY_Init
 *****************************************************************************/
void KEY_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    RCC_APB2PeriphClockCmd(KEY0_GPIO_CLK, ENABLE);
    RCC_APB2PeriphClockCmd(KEY1_GPIO_CLK, ENABLE);
    RCC_APB2PeriphClockCmd(OLED_KEY1_GPIO_CLK, ENABLE);
    RCC_APB2PeriphClockCmd(OLED_KEY2_GPIO_CLK, ENABLE);
    RCC_APB2PeriphClockCmd(OLED_KEY3_GPIO_CLK, ENABLE);
    RCC_APB2PeriphClockCmd(OLED_KEY4_GPIO_CLK, ENABLE);
    
    // KEY0����
    GPIO_InitStructure.GPIO_Pin = KEY0_GPIO_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(KEY0_GPIO_PORT, &GPIO_InitStructure);
    
    // KEY1����
    GPIO_InitStructure.GPIO_Pin = KEY1_GPIO_PIN;
    GPIO_Init(KEY1_GPIO_PORT, &GPIO_InitStructure);
    
    // OLED KEY1���� (PB7)
    GPIO_InitStructure.GPIO_Pin = OLED_KEY1_GPIO_PIN;
    GPIO_Init(OLED_KEY1_GPIO_PORT, &GPIO_InitStructure);
    
    // OLED KEY2���� (PB9)
    GPIO_InitStructure.GPIO_Pin = OLED_KEY2_GPIO_PIN;
    GPIO_Init(OLED_KEY2_GPIO_PORT, &GPIO_InitStructure);
    
    // OLED KEY3���� (PB11)
    GPIO_InitStructure.GPIO_Pin = OLED_KEY3_GPIO_PIN;
    GPIO_Init(OLED_KEY3_GPIO_PORT, &GPIO_InitStructure);
    
    // OLED KEY4���� (PB13)
    GPIO_InitStructure.GPIO_Pin = OLED_KEY4_GPIO_PIN;
    GPIO_Init(OLED_KEY4_GPIO_PORT, &GPIO_InitStructure);
}

/******************************************************************************
 * ��������: KEY_Scan
 * ��������: ����ɨ�裨��Ҫ����ѭ���ж��ڵ��ã�
 * ˵    ��: ʹ��TIM1_GetTick()��ȡϵͳʱ�ӣ�10ms��λ��
 *****************************************************************************/
void KEY_Scan(void)
{
    uint8_t key0_val = GPIO_ReadInputDataBit(KEY0_GPIO_PORT, KEY0_GPIO_PIN);
    uint8_t key1_val = GPIO_ReadInputDataBit(KEY1_GPIO_PORT, KEY1_GPIO_PIN);
    uint8_t oled_key1_val = GPIO_ReadInputDataBit(OLED_KEY1_GPIO_PORT, OLED_KEY1_GPIO_PIN);
    uint8_t oled_key2_val = GPIO_ReadInputDataBit(OLED_KEY2_GPIO_PORT, OLED_KEY2_GPIO_PIN);
    uint8_t oled_key3_val = GPIO_ReadInputDataBit(OLED_KEY3_GPIO_PORT, OLED_KEY3_GPIO_PIN);
    uint8_t oled_key4_val = GPIO_ReadInputDataBit(OLED_KEY4_GPIO_PORT, OLED_KEY4_GPIO_PIN);
    
    // KEY0ɨ�裨֧�ֳ�����
    switch (key0_state)
    {
        case KEY_STATE_IDLE:
            if (key0_val == 0)
            {
                key0_state = KEY_STATE_PRESSING;
                key0_press_time = TIM1_GetTick();
            }
            break;
            
        case KEY_STATE_PRESSING:
            if (key0_val == 0)
            {
                // �����жϣ�50��tick = 500ms
                if ((TIM1_GetTick() - key0_press_time) >= 50)
                {
                    key0_long_flag = 1;
                    key0_state = KEY_STATE_LONG_PRESSED;
                }
            }
            else
            {
                key0_flag = 1;
                key0_state = KEY_STATE_IDLE;
            }
            break;
            
        case KEY_STATE_LONG_PRESSED:
            if (key0_val == 1)
            {
                key0_state = KEY_STATE_IDLE;
            }
            break;
            
        default:
            key0_state = KEY_STATE_IDLE;
            break;
    }
    
    // KEY1ɨ�裨֧�ֳ�����
    switch (key1_state)
    {
        case KEY_STATE_IDLE:
            if (key1_val == 0)
            {
                key1_state = KEY_STATE_PRESSING;
                key1_press_time = TIM1_GetTick();
            }
            break;
            
        case KEY_STATE_PRESSING:
            if (key1_val == 0)
            {
                if ((TIM1_GetTick() - key1_press_time) >= 50)
                {
                    key1_long_flag = 1;
                    key1_state = KEY_STATE_LONG_PRESSED;
                }
            }
            else
            {
                key1_flag = 1;
                key1_state = KEY_STATE_IDLE;
            }
            break;
            
        case KEY_STATE_LONG_PRESSED:
            if (key1_val == 1)
            {
                key1_state = KEY_STATE_IDLE;
            }
            break;
            
        default:
            key1_state = KEY_STATE_IDLE;
            break;
    }
    
    // OLED KEY1ɨ�裨��������
    static uint8_t oled_key1_last = 1;
    if (oled_key1_val == 0 && oled_key1_last == 1)
    {
        oled_key1_flag = 1;
    }
    oled_key1_last = oled_key1_val;
    
    // OLED KEY2ɨ��
    static uint8_t oled_key2_last = 1;
    if (oled_key2_val == 0 && oled_key2_last == 1)
    {
        oled_key2_flag = 1;
    }
    oled_key2_last = oled_key2_val;
    
    // OLED KEY3ɨ��
    static uint8_t oled_key3_last = 1;
    if (oled_key3_val == 0 && oled_key3_last == 1)
    {
        oled_key3_flag = 1;
    }
    oled_key3_last = oled_key3_val;
    
    // OLED KEY4ɨ��
    static uint8_t oled_key4_last = 1;
    if (oled_key4_val == 0 && oled_key4_last == 1)
    {
        oled_key4_flag = 1;
    }
    oled_key4_last = oled_key4_val;
}

uint8_t KEY_GetKey0Flag(void)
{
    if (key0_flag) { key0_flag = 0; return 1; }
    return 0;
}

uint8_t KEY_GetKey1Flag(void)
{
    if (key1_flag) { key1_flag = 0; return 1; }
    return 0;
}

uint8_t KEY_GetKey0LongPressFlag(void)
{
    if (key0_long_flag) { key0_long_flag = 0; return 1; }
    return 0;
}

uint8_t KEY_GetKey1LongPressFlag(void)
{
    if (key1_long_flag) { key1_long_flag = 0; return 1; }
    return 0;
}

uint8_t KEY_GetOLEDKey1Flag(void)
{
    if (oled_key1_flag) { oled_key1_flag = 0; return 1; }
    return 0;
}

uint8_t KEY_GetOLEDKey2Flag(void)
{
    if (oled_key2_flag) { oled_key2_flag = 0; return 1; }
    return 0;
}

uint8_t KEY_GetOLEDKey3Flag(void)
{
    if (oled_key3_flag) { oled_key3_flag = 0; return 1; }
    return 0;
}

uint8_t KEY_GetOLEDKey4Flag(void)
{
    if (oled_key4_flag) { oled_key4_flag = 0; return 1; }
    return 0;
}


