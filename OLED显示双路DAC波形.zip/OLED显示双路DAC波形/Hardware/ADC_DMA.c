#include "ADC_DMA.h"
#include "delay.h"
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/******************** ȫ�ֱ������� ********************/
// DMAԭʼ�������������洢��
uint16_t ADC_Value_Raw[ADC_BUFFER_SIZE * ADC_CHANNEL_NUM] = {0};

// �⽻����Ļ�����
uint16_t ADC_Value[ADC_CHANNEL_NUM][ADC_BUFFER_SIZE] = {0};

// ʾ����ר�û�����
uint16_t Scope_ADC_Value[ADC_BUFFER_SIZE] = {0};

/******************************************************************************
 * ��������: ADC_Deinterleave
 * ��������: �⽻��ADC����
 *****************************************************************************/
void ADC_Deinterleave(void)
{
    uint16_t i;
    for (i = 0; i < ADC_BUFFER_SIZE; i++)
    {
        ADC_Value[0][i] = ADC_Value_Raw[i * 2];      // CH0 (PA0)
        ADC_Value[1][i] = ADC_Value_Raw[i * 2 + 1];  // CH1 (PA1)
    }
}

/******************************************************************************
 * ��������: ADC_DMA_Init
 * ��������: ��ʼ��ADC1˫ͨ��DMAģʽ
 * ˵    ��: PA0 -> ADC_Channel_0 -> �ɼ�DAC1(PA4)���ź�
 *           PA1 -> ADC_Channel_1 -> �ɼ�DAC2(PA5)���ź�
 *****************************************************************************/
void ADC_DMA_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    ADC_InitTypeDef ADC_InitStructure;
    DMA_InitTypeDef DMA_InitStructure;
    
    // 1. ʹ��ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    
    // ADCʱ�ӣ�72MHz/6 = 12MHz
    RCC_ADCCLKConfig(RCC_PCLK2_Div6);
    
    // 2. GPIO���ã�ģ�����룩- PA0��PA1
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // 3. DMA����
    DMA_DeInit(DMA1_Channel1);
    
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&ADC1->DR;
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)ADC_Value_Raw;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
    DMA_InitStructure.DMA_BufferSize = ADC_BUFFER_SIZE * ADC_CHANNEL_NUM;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel1, &DMA_InitStructure);
    
    DMA_Cmd(DMA1_Channel1, ENABLE);
    
    // 4. ADC����
    ADC_DeInit(ADC1);
    
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode = ENABLE;           // ɨ��ģʽ
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;     // ����ת��
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = ADC_CHANNEL_NUM;  // 2��ͨ��
    ADC_Init(ADC1, &ADC_InitStructure);
    
    // 5. ���ù�����ͨ����˳�����Ҫ����
    // ����1: PA0 (Channel 0)
    ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_55Cycles5);
    // ����2: PA1 (Channel 1)
    ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 2, ADC_SampleTime_55Cycles5);
    
    // 6. ʹ��DMA����
    ADC_DMACmd(ADC1, ENABLE);
    
    // 7. ʹ��ADC
    ADC_Cmd(ADC1, ENABLE);
    
    // 8. ADCУ׼
    ADC_ResetCalibration(ADC1);
    while(ADC_GetResetCalibrationStatus(ADC1));
    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));
    
    // 9. ����ADCת��
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}

/******************************************************************************
 * ��������: ADC_GetValue
 *****************************************************************************/
uint16_t ADC_GetValue(uint8_t channel, uint16_t index)
{
    if (channel < ADC_CHANNEL_NUM && index < ADC_BUFFER_SIZE)
    {
        return ADC_Value[channel][index];
    }
    return 0;
}

/******************************************************************************
 * ��������: ADC_GetVoltage
 *****************************************************************************/
float ADC_GetVoltage(uint8_t channel, uint16_t index)
{
    if (channel < ADC_CHANNEL_NUM && index < ADC_BUFFER_SIZE)
    {
        return (float)ADC_Value[channel][index] * 3.3f / 4095.0f;
    }
    return 0.0f;
}

/******************************************************************************
 * ��������: Scope_ADC_CalculateParams_CH1
 * ��������: ����ͨ��1(PA0)��Ƶ�ʺͷ��ֵ
 *****************************************************************************/
void Scope_ADC_CalculateParams_CH1(float *freq, float *vpp)
{
    uint16_t i;
    uint16_t max_val = 0, min_val = 4095;
    uint16_t mid_val;
    uint8_t last_state = 0;
    uint32_t rising_edge_pos[10] = {0};
    uint8_t edge_count = 0;
    
    // �������ֵ����Сֵ
    for (i = 0; i < ADC_BUFFER_SIZE; i++)
    {
        if (ADC_Value[0][i] > max_val)
            max_val = ADC_Value[0][i];
        if (ADC_Value[0][i] < min_val)
            min_val = ADC_Value[0][i];
    }
    
    // ������ֵ
    *vpp = (float)(max_val - min_val) * 3.3f / 4095.0f;
    
    if (*vpp < 0.1f)
    {
        *freq = 0;
        return;
    }
    
    mid_val = (max_val + min_val) / 2;
    
    // �������
    for (i = 1; i < ADC_BUFFER_SIZE; i++)
    {
        uint8_t current_state = (ADC_Value[0][i] > mid_val) ? 1 : 0;
        
        if (current_state == 1 && last_state == 0)
        {
            if (edge_count < 10)
            {
                rising_edge_pos[edge_count] = i;
                edge_count++;
            }
        }
        last_state = current_state;
    }
    
    // ����Ƶ��
    if (edge_count >= 2)
    {
        uint32_t avg_period = (rising_edge_pos[edge_count - 1] - rising_edge_pos[0]) / (edge_count - 1);
        if (avg_period > 0)
        {
            // �����ʣ�12MHz / 68 / 2 = 88.2kHz (ÿͨ��)
            *freq = 88200.0f / (float)avg_period;
        }
        else
        {
            *freq = 0;
        }
    }
    else
    {
        *freq = 0;
    }
    
    if (*freq > 44000.0f || *freq < 1.0f)
        *freq = 0;
}

/******************************************************************************
 * ��������: Scope_ADC_CalculateParams_CH2
 * ��������: ����ͨ��2(PA1)��Ƶ�ʺͷ��ֵ
 *****************************************************************************/
void Scope_ADC_CalculateParams_CH2(float *freq, float *vpp)
{
    uint16_t i;
    uint16_t max_val = 0, min_val = 4095;
    uint16_t mid_val;
    uint8_t last_state = 0;
    uint32_t rising_edge_pos[10] = {0};
    uint8_t edge_count = 0;
    
    // �������ֵ����Сֵ
    for (i = 0; i < ADC_BUFFER_SIZE; i++)
    {
        if (ADC_Value[1][i] > max_val)
            max_val = ADC_Value[1][i];
        if (ADC_Value[1][i] < min_val)
            min_val = ADC_Value[1][i];
    }
    
    // ������ֵ
    *vpp = (float)(max_val - min_val) * 3.3f / 4095.0f;
    
    if (*vpp < 0.1f)
    {
        *freq = 0;
        return;
    }
    
    mid_val = (max_val + min_val) / 2;
    
    // �������
    for (i = 1; i < ADC_BUFFER_SIZE; i++)
    {
        uint8_t current_state = (ADC_Value[1][i] > mid_val) ? 1 : 0;
        
        if (current_state == 1 && last_state == 0)
        {
            if (edge_count < 10)
            {
                rising_edge_pos[edge_count] = i;
                edge_count++;
            }
        }
        last_state = current_state;
    }
    
    // ����Ƶ��
    if (edge_count >= 2)
    {
        uint32_t avg_period = (rising_edge_pos[edge_count - 1] - rising_edge_pos[0]) / (edge_count - 1);
        if (avg_period > 0)
        {
            *freq = 88200.0f / (float)avg_period;
        }
        else
        {
            *freq = 0;
        }
    }
    else
    {
        *freq = 0;
    }
    
    if (*freq > 44000.0f || *freq < 1.0f)
        *freq = 0;
}

/******************************************************************************
 * ��������: Scope_ADC_CalculatePhase_CH1_CH2
 *****************************************************************************/
float Scope_ADC_CalculatePhase_CH1_CH2(void)
{
    uint16_t i;
    uint16_t ch1_max = 0, ch1_min = 4095;
    uint16_t ch2_max = 0, ch2_min = 4095;
    uint16_t ch1_mid, ch2_mid;
    uint8_t ch1_last_state = 0, ch2_last_state = 0;
    int32_t ch1_first_rising = -1, ch2_first_rising = -1;
    float ch1_vpp, ch2_vpp;
    float phase_diff_deg;
    uint32_t ch1_period = 0, ch2_period = 0;
    uint8_t ch1_edge_count = 0, ch2_edge_count = 0;
    uint32_t ch1_rising_edges[10] = {0};
    uint32_t ch2_rising_edges[10] = {0};
    
    // ���������Сֵ
    for (i = 0; i < ADC_BUFFER_SIZE; i++)
    {
        if (ADC_Value[0][i] > ch1_max) ch1_max = ADC_Value[0][i];
        if (ADC_Value[0][i] < ch1_min) ch1_min = ADC_Value[0][i];
        if (ADC_Value[1][i] > ch2_max) ch2_max = ADC_Value[1][i];
        if (ADC_Value[1][i] < ch2_min) ch2_min = ADC_Value[1][i];
    }
    
    ch1_vpp = (float)(ch1_max - ch1_min) * 3.3f / 4095.0f;
    ch2_vpp = (float)(ch2_max - ch2_min) * 3.3f / 4095.0f;
    
    if (ch1_vpp < 0.1f || ch2_vpp < 0.1f)
    {
        return 0.0f;
    }
    
    ch1_mid = (ch1_max + ch1_min) / 2;
    ch2_mid = (ch2_max + ch2_min) / 2;
    
    // Ѱ��������
    for (i = 1; i < ADC_BUFFER_SIZE; i++)
    {
        uint8_t ch1_current_state = (ADC_Value[0][i] > ch1_mid) ? 1 : 0;
        if (ch1_current_state == 1 && ch1_last_state == 0)
        {
            if (ch1_first_rising == -1) ch1_first_rising = i;
            if (ch1_edge_count < 10) ch1_rising_edges[ch1_edge_count++] = i;
        }
        ch1_last_state = ch1_current_state;
        
        uint8_t ch2_current_state = (ADC_Value[1][i] > ch2_mid) ? 1 : 0;
        if (ch2_current_state == 1 && ch2_last_state == 0)
        {
            if (ch2_first_rising == -1) ch2_first_rising = i;
            if (ch2_edge_count < 10) ch2_rising_edges[ch2_edge_count++] = i;
        }
        ch2_last_state = ch2_current_state;
    }
    
    if (ch1_first_rising == -1 || ch2_first_rising == -1)
    {
        return 0.0f;
    }
    
    if (ch1_edge_count >= 2)
        ch1_period = (ch1_rising_edges[ch1_edge_count - 1] - ch1_rising_edges[0]) / (ch1_edge_count - 1);
    if (ch2_edge_count >= 2)
        ch2_period = (ch2_rising_edges[ch2_edge_count - 1] - ch2_rising_edges[0]) / (ch2_edge_count - 1);
    
    if (ch1_period == 0 || ch2_period == 0)
    {
        return 0.0f;
    }
    
    float period_ratio = (float)ch1_period / (float)ch2_period;
    if (period_ratio < 0.9f || period_ratio > 1.1f)
    {
        return 0.0f;
    }
    
    int32_t phase_diff_samples = ch1_first_rising - ch2_first_rising;
    uint32_t avg_period = (ch1_period + ch2_period) / 2;
    
    phase_diff_deg = (float)phase_diff_samples / (float)avg_period * 360.0f;
    
    while (phase_diff_deg > 180.0f) phase_diff_deg -= 360.0f;
    while (phase_diff_deg < -180.0f) phase_diff_deg += 360.0f;
    
    return phase_diff_deg;
}

/******************************************************************************
 * ��������: Scope_ADC_GetPhaseInfo
 *****************************************************************************/
void Scope_ADC_GetPhaseInfo(float *phase_deg, float *phase_rad, uint8_t *is_valid)
{
    float ch1_freq, ch1_vpp;
    float ch2_freq, ch2_vpp;
    
    Scope_ADC_CalculateParams_CH1(&ch1_freq, &ch1_vpp);
    Scope_ADC_CalculateParams_CH2(&ch2_freq, &ch2_vpp);
    
    if (ch1_freq < 1.0f || ch2_freq < 1.0f)
    {
        *phase_deg = 0.0f;
        *phase_rad = 0.0f;
        *is_valid = 0;
        return;
    }
    
    float freq_ratio = ch1_freq / ch2_freq;
    if (freq_ratio < 0.9f || freq_ratio > 1.1f)
    {
        *phase_deg = 0.0f;
        *phase_rad = 0.0f;
        *is_valid = 0;
        return;
    }
    
    *phase_deg = Scope_ADC_CalculatePhase_CH1_CH2();
    *phase_rad = *phase_deg * M_PI / 180.0f;
    *is_valid = 1;
}

/******************************************************************************
 * ��������: ADC_GetVoltage_CH1
 *****************************************************************************/
float ADC_GetVoltage_CH1(uint16_t index)
{
    if (index < ADC_BUFFER_SIZE)
        return (float)ADC_Value[0][index] * 3.3f / 4095.0f;
    return 0;
}

/******************************************************************************
 * ��������: ADC_GetVoltage_CH2
 *****************************************************************************/
float ADC_GetVoltage_CH2(uint16_t index)
{
    if (index < ADC_BUFFER_SIZE)
        return (float)ADC_Value[1][index] * 3.3f / 4095.0f;
    return 0;
}

/******************************************************************************
 * ��������: Scope_ADC_Init
 *****************************************************************************/
void Scope_ADC_Init(void)
{
    // �����ӿ�
}

/******************************************************************************
 * ��������: ADC_SwitchMode
 *****************************************************************************/
void ADC_SwitchMode(uint8_t mode)
{
    // �����ӿ�
}


