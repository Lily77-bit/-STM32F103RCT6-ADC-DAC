#include "Timer.h"


/******************** ȫ�ֱ������� ********************/
volatile EC11_Event ec11_event = NO_EVENT;
volatile uint32_t system_tick = 0;
volatile TaskFlag_t task_flag = {0, 0, 0, 0};  // ����

// EC11״̬����
static uint8_t ec11_last_state = 0x03;
static uint8_t ec11_key_state = 1;
static uint8_t ec11_key_last = 1;
static uint16_t ec11_key_count = 0;



// �����Ƶ��������������
static uint8_t key_scan_divider = 0;      // ����ɨ���Ƶ
static uint8_t ui_update_divider = 0;     // UI���·�Ƶ
static uint8_t led_update_divider = 0;    // LED���·�Ƶ
static uint8_t wave_refresh_divider = 0;  // ����ˢ�·�Ƶ
static uint8_t pa8_counter = 0;

/******************************************************************************
 * ��������: PA8_LED_Init
 *****************************************************************************/
void PA8_LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    GPIO_ResetBits(GPIOA, GPIO_Pin_8);
}

/******************************************************************************
 * ��������: PA8_Toggle
 *****************************************************************************/
void PA8_Toggle(void)
{
    if (GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_8))
    {
        GPIO_ResetBits(GPIOA, GPIO_Pin_8);
    }
    else
    {
        GPIO_SetBits(GPIOA, GPIO_Pin_8);
    }
}

/******************************************************************************
 * ��������: TIM1_System_Init
 *****************************************************************************/
void TIM1_System_Init(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
    
    // 72MHz / 7200 / 100 = 100Hz (10ms)
    TIM_TimeBaseStructure.TIM_Period = 100 - 1;
    TIM_TimeBaseStructure.TIM_Prescaler = 7200 - 1;
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);
    
    TIM_ClearFlag(TIM1, TIM_FLAG_Update);
    TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    TIM_Cmd(TIM1, ENABLE);
}

/******************************************************************************
 * ��������: TIM1_GetTick
 *****************************************************************************/
uint32_t TIM1_GetTick(void)
{
    return system_tick;
}


/******************************************************************************
 * ��������: EC11_Scan (�ڲ�����)
 *****************************************************************************/
static void EC11_Scan(void)
{
    uint8_t current_state;
    uint8_t current_key;
    
    // ��ת��� 
    current_state = (GPIO_ReadInputDataBit(EC11_A_PORT, EC11_A_PIN) << 1) | 
                    GPIO_ReadInputDataBit(EC11_B_PORT, EC11_B_PIN);
    
    if (ec11_last_state == 0x03 && current_state != 0x03)
    {
        if (ec11_event == NO_EVENT)
        {
            if (current_state == 0x01)
            {
                ec11_event = CW;
            }
            else if (current_state == 0x02)
            {
                ec11_event = CCW;
            }
        }
    }
    
    ec11_last_state = current_state;
    
    // ������
    current_key = GPIO_ReadInputDataBit(EC11_C_PORT, EC11_C_PIN); 
    
    if (current_key != ec11_key_last)
    {
        ec11_key_count = 0;
        ec11_key_last = current_key;
    }
    else
    {
        if (ec11_key_count < 1000)
        {
            ec11_key_count++;
        }
        
        if (ec11_key_count == 3)
        {
            if (current_key == 0 && ec11_key_state == 1)
            {
                ec11_key_state = 0;
                if (ec11_event == NO_EVENT)
                {
                    ec11_event = PRESS_DOWN;
                }
            }
            else if (current_key == 1 && ec11_key_state == 0)
            {
                ec11_key_state = 1;
            }
        }
    }
}


/******************************************************************************
 * ��������: EC11_GetEvent
 *****************************************************************************/
EC11_Event EC11_GetEvent(void)
{
    return ec11_event;
}

/******************************************************************************
 * ��������: EC11_ClearEvent
 *****************************************************************************/
void EC11_ClearEvent(void)
{
    ec11_event = NO_EVENT;
}

/******************************************************************************
 * ��������: TIM1_UP_IRQHandler
 * ˵    ��: 10ms�жϣ�ͨ����Ƶ���Ƹ�����ִ��Ƶ��
 *****************************************************************************/
void TIM1_UP_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM1, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
        
        // ϵͳtick����
        system_tick++;
        
        // EC11ɨ�裨ÿ�ζ�ִ�У�10ms��
        EC11_Scan();
        
        // ===== ����ɨ���־ (ÿ20ms����Ƶ2) =====
        key_scan_divider++;
        if (key_scan_divider >= 2)
        {
            key_scan_divider = 0;
            task_flag.key_scan_flag = 1;
        }
        
        // ===== UI���±�־ (ÿ50ms����Ƶ5) =====
        ui_update_divider++;
        if (ui_update_divider >= 5)
        {
            ui_update_divider = 0;
            task_flag.ui_update_flag = 1;
        }
        
        // ===== LED���±�־ (ÿ50ms����Ƶ5) =====
        led_update_divider++;
        if (led_update_divider >= 5)
        {
            led_update_divider = 0;
            task_flag.led_update_flag = 1;
        }
        
        // ===== ����ˢ�±�־ (ÿ100ms����Ƶ10) =====
        wave_refresh_divider++;
        if (wave_refresh_divider >= 10)
        {
            wave_refresh_divider = 0;
            task_flag.wave_refresh_flag = 1;
        }
        
        // PA8ÿ1�뷭ת (100 * 10ms = 1s)
        pa8_counter++;
        if (pa8_counter >= 100)
        {
            pa8_counter = 0;
            PA8_Toggle();
        }
    }
}

/******************************************************************************
 * ����ΪTIM2/TIM3/TIM4���������ֲ���
 *****************************************************************************/
void TIM2_DAC1_Init(uint32_t frequency)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    uint32_t arr;
    
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    
    if (frequency == 0) frequency = 1;
    arr = 72000000 / (WAVE_BUFFER_SIZE_TIM * frequency) - 1;
    if (arr > 65535) arr = 65535;
    if (arr < 1) arr = 1;
    
    TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
    TIM_TimeBaseStructure.TIM_Period = arr;
    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
    
    TIM_SelectOutputTrigger(TIM2, TIM_TRGOSource_Update);
    TIM_Cmd(TIM2, ENABLE);
}

void TIM2_DAC1_SetFrequency(uint32_t frequency)
{
    uint32_t arr;
    
    if (frequency == 0) frequency = 1;
    arr = 72000000 / (WAVE_BUFFER_SIZE_TIM * frequency) - 1;
    if (arr > 65535) arr = 65535;
    if (arr < 1) arr = 1;
    
    TIM_SetAutoreload(TIM2, arr);
    TIM2->CNT = 0;
}


void TIM4_DAC2_Init(uint32_t frequency)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    uint32_t arr;
    
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
    
    if (frequency == 0) frequency = 1;
    arr = 72000000 / (WAVE_BUFFER_SIZE_TIM * frequency) - 1;
    if (arr > 65535) arr = 65535;
    if (arr < 1) arr = 1;
    
    TIM_TimeBaseStructure.TIM_Period = arr;
    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
    
    TIM_SelectOutputTrigger(TIM4, TIM_TRGOSource_Update);
    TIM_Cmd(TIM4, ENABLE);
}

void TIM4_DAC2_SetFrequency(uint32_t frequency)
{
    uint32_t arr;
    
    if (frequency == 0) frequency = 1;
    arr = 72000000 / (WAVE_BUFFER_SIZE_TIM * frequency) - 1;
    if (arr > 65535) arr = 65535;
    if (arr < 1) arr = 1;
    
    TIM_SetAutoreload(TIM4, arr);
    TIM4->CNT = 0;
}



