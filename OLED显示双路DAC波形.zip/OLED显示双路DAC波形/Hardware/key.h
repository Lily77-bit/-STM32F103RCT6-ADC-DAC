#ifndef __KEY_H
#define __KEY_H

#include "stm32f10x.h"

// KEY0: PC5
#define KEY0_GPIO_PORT   GPIOC
#define KEY0_GPIO_PIN    GPIO_Pin_5
#define KEY0_GPIO_CLK    RCC_APB2Periph_GPIOC

// KEY1: PA15
#define KEY1_GPIO_PORT   GPIOA
#define KEY1_GPIO_PIN    GPIO_Pin_15
#define KEY1_GPIO_CLK    RCC_APB2Periph_GPIOA

// OLED KEY4: PB13
#define OLED_KEY4_GPIO_PORT   GPIOB
#define OLED_KEY4_GPIO_PIN    GPIO_Pin_13
#define OLED_KEY4_GPIO_CLK    RCC_APB2Periph_GPIOB

// OLED KEY3: PB11
#define OLED_KEY3_GPIO_PORT   GPIOB
#define OLED_KEY3_GPIO_PIN    GPIO_Pin_11
#define OLED_KEY3_GPIO_CLK    RCC_APB2Periph_GPIOB

// OLED KEY2: PB9
#define OLED_KEY2_GPIO_PORT   GPIOB
#define OLED_KEY2_GPIO_PIN    GPIO_Pin_9
#define OLED_KEY2_GPIO_CLK    RCC_APB2Periph_GPIOB

// OLED KEY1: PB7
#define OLED_KEY1_GPIO_PORT   GPIOB
#define OLED_KEY1_GPIO_PIN    GPIO_Pin_7
#define OLED_KEY1_GPIO_CLK    RCC_APB2Periph_GPIOB

// ����ʱ�䶨�壨��λ��10ms��50 = 500ms��
#define KEY_LONG_PRESS_TIME  50

// ����״̬ö��
typedef enum {
    KEY_STATE_IDLE = 0,
    KEY_STATE_PRESSING,
    KEY_STATE_PRESSED,
    KEY_STATE_LONG_PRESSED
} KEY_State;

// ��������
void KEY_Init(void);
void KEY_Scan(void);

uint8_t KEY_GetKey0Flag(void);
uint8_t KEY_GetKey1Flag(void);
uint8_t KEY_GetKey0LongPressFlag(void);
uint8_t KEY_GetKey1LongPressFlag(void);

uint8_t KEY_GetOLEDKey1Flag(void);
uint8_t KEY_GetOLEDKey2Flag(void);
uint8_t KEY_GetOLEDKey3Flag(void);
uint8_t KEY_GetOLEDKey4Flag(void);

#endif


