#include "stm32f10x.h"
#include "delay.h"
#include "OLED.h"
#include "EC11.h"
#include "KEY.h"
#include "ADC_DMA.h"
#include "DAC_DMA.h"
#include "Timer.h"
#include "UI.h"

int main(void)
{
    uint8_t led_state = 0;
    
    // ϵͳ��ʼ��
    PA8_LED_Init();
    OLED_Init();
    EC11_Init();
    KEY_Init();
    ADC_DMA_Init();
    DAC_DMA_Init();
	
     // ��ʾ��ӭ����
    OLED_Clear();
    OLED_ShowString(40, 0, "STM32", OLED_8X16);
	  OLED_ShowImage(100,0,16,16,Diode);
	
	
    OLED_ShowString(20, 18, "Application", OLED_8X16);
    OLED_ShowString(36, 38, "������", OLED_12X12);
    OLED_ShowString(30, 56, "3023234542", OLED_6X8);
    OLED_Update();
    // ��ʱ����ʼ��
    TIM1_System_Init();
    TIM2_DAC1_Init(1000);
    TIM4_DAC2_Init(1000);
    
    // UI��ʼ��
    UI_Init();
    

    delay_ms(2000);
    
    // ��ʾ���˵�
    OLED_Clear();
    OLED_ShowString(18, 0, "Dual Channel", OLED_8X16);
    OLED_ShowString(8, 16, "Wave Generator", OLED_8X16);
    OLED_ShowString(18, 33, "KEY0: Config", OLED_6X8);
    OLED_ShowString(18, 45, "KEY1: Edit", OLED_6X8);
    OLED_ShowString(0, 56, "PA8:", OLED_6X8);
    OLED_ShowString(30, 56, "ON", OLED_6X8);
    OLED_Update();
    
    while (1)
    {
        // ===== ����ɨ������ (ÿ20ms) =====
        if (task_flag.key_scan_flag)
        {
            task_flag.key_scan_flag = 0;
            
            KEY_Scan();
            
            // KEY0: �˵��л�
            if (KEY_GetKey0Flag())
            {
                if (ui_param.state == UI_STATE_IDLE)
                {
                    UI_EnterMenu1();
                }
                else if (ui_param.state == UI_STATE_MENU1)
                {
                    UI_EnterMenu2();
                }
                else if (ui_param.state == UI_STATE_MENU2)
                {
                    ui_param.scope_param.show_multiply = 0;
                    ui_param.scope_param.wave_select = WAVE_SELECT_NONE;
                    ui_param.scope_param.phase_editing = 0;
                    
                    UI_ExitMenu1();
                    
                    OLED_Clear();
                    OLED_ShowString(10, 0, "Dual Channel", OLED_8X16);
                    OLED_ShowString(10, 16, "Wave Generator", OLED_8X16);
                    OLED_ShowString(10, 36, "KEY0: Config", OLED_6X8);
                    OLED_ShowString(10, 44, "KEY1: Edit", OLED_6X8);
                    OLED_ShowString(0, 56, "PA8:", OLED_6X8);
                    OLED_Update();
                }
            }
            
            // KEY1�̰�: ȷ�ϱ༭
            if (KEY_GetKey1Flag())
            {
                if (ui_param.state == UI_STATE_MENU1)
                {
                    UI_ConfirmEdit();
                }
            }
            
            // KEY1����: �˵�����
            if (KEY_GetKey1LongPressFlag())
            {
                if (ui_param.state == UI_STATE_MENU1)
                {
                    UI_ToggleMenu1Scroll();
                }
            }
            
            // OLED KEY1-4
            if (KEY_GetOLEDKey1Flag())
            {
                if (ui_param.state == UI_STATE_MENU2)
                {
                    UI_SelectWave(WAVE_SELECT_CH1);
                }
            }
            
            if (KEY_GetOLEDKey2Flag())
            {
                if (ui_param.state == UI_STATE_MENU2)
                {
                    UI_SelectWave(WAVE_SELECT_CH2);
                }
            }
            
            if (KEY_GetOLEDKey3Flag())
            {
                if (ui_param.state == UI_STATE_MENU2)
                {
                    UI_TogglePhaseEdit();
                }
            }
            
            if (KEY_GetOLEDKey4Flag())
            {
                if (ui_param.state == UI_STATE_MENU2)
                {
                    UI_ToggleMenu2Scroll();
                }
            }
            
            // ����UI�¼���EC11��
            UI_Handle();
        }
        
        // ===== LED״̬�������� (ÿ50ms) =====
        if (task_flag.led_update_flag)
        {
            task_flag.led_update_flag = 0;
            
            if (ui_param.state == UI_STATE_IDLE)
            {
                led_state = GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_8);
                OLED_ShowString(30, 56, led_state ? "OFF" : "ON ", OLED_6X8);
                OLED_Update();
            }
        }
        
        // ===== ����ˢ������ (ÿ100ms) =====
        if (task_flag.wave_refresh_flag)
        {
            task_flag.wave_refresh_flag = 0;
            
            if (ui_param.state == UI_STATE_MENU2)
            {
                ADC_Deinterleave();
                
                if (ui_param.scope_param.is_running)
                {
                    UI_Scope_UpdateMeasure();
                }
                
                if (ui_param.scope_param.show_multiply)
                {
                    UI_DrawMenu2_Multiply();
                }
                else
                {
                    UI_DrawMenu2();
                }
                OLED_Update();
            }
        }
        
        // ��ѭ���������ӵ͹��ĵȴ�
        // __WFI();  // �ȴ��жϣ����͹���
    }
}


